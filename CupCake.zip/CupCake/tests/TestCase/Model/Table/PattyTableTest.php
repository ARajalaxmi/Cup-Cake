<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\PattyTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\PattyTable Test Case
 */
class PattyTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\PattyTable
     */
    protected $Patty;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.Patty',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Patty') ? [] : ['className' => PattyTable::class];
        $this->Patty = $this->getTableLocator()->get('Patty', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Patty);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\PattyTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
